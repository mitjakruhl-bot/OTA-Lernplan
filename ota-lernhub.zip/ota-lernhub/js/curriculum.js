// OTA Ausbildungscurriculum – eRef Thieme
// Vollständige Struktur KS1–KS8 mit allen Unterebenen

const CURRICULUM = [
  {
    id: 'KS1',
    name: 'Berufsbezogene Aufgaben',
    icon: '🔬',
    color: '#185FA5',
    colorBg: '#E6F1FB',
    total: 1605,
    bereiche: [
      {
        id: 'KS1a', name: 'Patientensicherheit',
        total: 28,
        themen: [
          { name: 'Patientensicherheit im operativen Bereich', total: 17 },
          { name: 'Team-Time-Out', total: 6 },
          { name: 'Recht und Patientensicherheit', total: 5 }
        ]
      },
      {
        id: 'KS1b', name: 'Prä-, intra- und postoperative Maßnahmen',
        total: 52,
        themen: [
          { name: 'Präoperative Pflegevisite', total: 2 },
          { name: 'Patientenüberwachung', total: 21 },
          { name: 'Prophylaxen', total: 21 },
          { name: 'Wärmemanagement', total: 8 }
        ]
      },
      {
        id: 'KS1c', name: 'Operationsverfahren und Diagnostik',
        total: 965,
        themen: [
          { name: 'Allgemeines – Chirurgische Notfälle', total: 15 },
          { name: 'Allgemeines – Grundlegendes', total: 61 },
          { name: 'Allgemeines – Allgemeine Techniken', total: 3 },
          { name: 'Allgemeines – Chirurgische Intensivmedizin', total: 3 },
          { name: 'Allgemein- und Viszeralchirurgie', total: 258 },
          { name: 'Augenchirurgie', total: 14 },
          { name: 'Endokrine, bariatrische und metabolische Chirurgie', total: 6 },
          { name: 'Gefäßchirurgie', total: 27 },
          { name: 'Gynäkologie – Grundlegendes / OP-Vorbereitung', total: 5 },
          { name: 'Gynäkologie – Vulva und Vagina', total: 9 },
          { name: 'Gynäkologie – Beckenboden und Uterus', total: 24 },
          { name: 'Gynäkologie – Mamma', total: 14 },
          { name: 'Gynäkologie – Störungen der Schwangerschaft', total: 3 },
          { name: 'Gynäkologie – Spezielle Operationstechniken', total: 4 },
          { name: 'Gynäkologie – Komplikationen', total: 12 },
          { name: 'Herzchirurgie', total: 39 },
          { name: 'Organentnahme und -transplantation', total: 23 },
          { name: 'Orthopädie & Unfallchirurgie – Allgemeines', total: 20 },
          { name: 'Orthopädie & Unfallchirurgie – Obere Extremitäten', total: 55 },
          { name: 'Orthopädie & Unfallchirurgie – Schulter', total: 45 },
          { name: 'Orthopädie & Unfallchirurgie – Handchirurgie', total: 34 },
          { name: 'Orthopädie & Unfallchirurgie – Becken und Hüfte', total: 29 },
          { name: 'Orthopädie & Unfallchirurgie – Kniegelenk', total: 33 },
          { name: 'Orthopädie & Unfallchirurgie – Untere Extremitäten', total: 75 },
          { name: 'Orthopädie & Unfallchirurgie – Wirbelsäule', total: 38 },
          { name: 'Plastische und Wiederherstellungschirurgie', total: 14 },
          { name: 'Thoraxchirurgie', total: 40 },
          { name: 'Urologie – Allgemeines', total: 1 },
          { name: 'Urologie – Blase', total: 2 },
          { name: 'Urologie – Männliche Genitale', total: 10 },
          { name: 'Urologie – Niere', total: 14 },
          { name: 'Urologie – Ableitende Harnwege', total: 4 },
          { name: 'Urologie – Weitere Eingriffe', total: 1 },
          { name: 'Bildgebung', total: 30 }
        ]
      },
      {
        id: 'KS1d', name: 'Grundlagenwissen und Vorbereitung operativer Eingriffe',
        total: 360,
        themen: [
          { name: 'Naturwissenschaftliche Grundlagen', total: 25 },
          { name: 'Anatomie', total: 164 },
          { name: 'Physiologie', total: 110 },
          { name: 'Mikrobiologie', total: 19 },
          { name: 'Lagerung', total: 29 },
          { name: 'OP- und Patientenvorbereitung', total: 13 }
        ]
      },
      {
        id: 'KS1e', name: 'Instrumentation',
        total: 25,
        themen: [
          { name: 'Instrumentieren', total: 25 }
        ]
      },
      {
        id: 'KS1f', name: 'Nachbereitung operativer Eingriffe',
        total: 15,
        themen: [
          { name: 'Patientenwechsel', total: 3 },
          { name: 'Reinigung und Aufrüstung von Eingriffsräumen', total: 12 }
        ]
      },
      {
        id: 'KS1g', name: 'Springertätigkeit',
        total: 8,
        themen: [
          { name: 'Springertätigkeit', total: 8 }
        ]
      },
      {
        id: 'KS1h', name: 'Medizinisch-technische Geräte',
        total: 39,
        themen: [
          { name: 'Gesetzliche Grundlagen und Rahmenbedingungen', total: 11 },
          { name: 'Gerätekunde', total: 28 }
        ]
      },
      {
        id: 'KS1i', name: 'Geräte, Medizinprodukte und Arzneimittel',
        total: 45,
        themen: [
          { name: 'Medizinisch-technische Geräte und Medizinprodukte', total: 13 },
          { name: 'Endoskopie', total: 10 },
          { name: 'Arzneimittel', total: 22 }
        ]
      },
      {
        id: 'KS1j', name: 'Ambulanzen, Notaufnahme, Funktionsbereiche',
        total: 57,
        themen: [
          { name: 'Station und Ambulanz', total: 14 },
          { name: 'Herzkatheterlabor', total: 12 },
          { name: 'Notaufnahme', total: 31 }
        ]
      },
      {
        id: 'KS1k', name: 'Übergabe, Übernahme und Dokumentation',
        total: 11,
        themen: [
          { name: 'OP-Beschreibung und -Dokumentation', total: 3 },
          { name: 'Patientenübergabe', total: 8 }
        ]
      }
    ]
  },
  {
    id: 'KS2',
    name: 'Medizinische Diagnostik und Therapie',
    icon: '🩺',
    color: '#993C1D',
    colorBg: '#FAECE7',
    total: 937,
    bereiche: [
      {
        id: 'KS2a', name: 'Krankheitslehre, Diagnostik und Therapie',
        total: 794,
        themen: [
          { name: 'Dermatologie', total: 19 },
          { name: 'Endokrinologie und Metabolismus', total: 28 },
          { name: 'Gastroenterologie', total: 98 },
          { name: 'Geriatrie', total: 21 },
          { name: 'Gynäkologie', total: 51 },
          { name: 'Hämatologie & Onkologie', total: 28 },
          { name: 'Herz / Kreislauf / Gefäße', total: 34 },
          { name: 'Infektionskrankheiten', total: 130 },
          { name: 'Neurologie', total: 51 },
          { name: 'Ophthalmologie', total: 51 },
          { name: 'Orthopädie / Traumatologie', total: 115 },
          { name: 'Pulmologie', total: 14 },
          { name: 'Rheumatologie und Immunologie', total: 18 },
          { name: 'Urologie und Nephrologie', total: 92 },
          { name: 'Anästhesieverfahren', total: 19 },
          { name: 'Anästhesiologische perioperative Komplikationen', total: 19 },
          { name: 'Wunden und Wundmanagement', total: 6 }
        ]
      },
      {
        id: 'KS2b', name: 'Ärztliche Anordnungen',
        total: 37,
        themen: [
          { name: 'Schmerztherapie und Betäubungsmittel', total: 7 },
          { name: 'Elektrokardiografie (EKG)', total: 3 },
          { name: 'Infusionen / Transfusionen', total: 9 },
          { name: 'Injektionen', total: 3 },
          { name: 'Punktionen und Blutabnahme', total: 15 }
        ]
      },
      {
        id: 'KS2c', name: 'Strahlenschutz',
        total: 6,
        themen: [
          { name: 'Strahlenschutz', total: 6 }
        ]
      },
      {
        id: 'KS2d', name: 'Rechtliche Aspekte der Delegation',
        total: 9,
        themen: [
          { name: 'Rechtliche Aspekte der Delegation', total: 9 }
        ]
      },
      {
        id: 'KS2e', name: 'Weitere Funktionsbereiche',
        total: 91,
        themen: [
          { name: 'Krankheitsbilder: Endoskopie', total: 55 },
          { name: 'Krankheitsbilder: Herzkatheterlabor', total: 23 },
          { name: 'Krankheitsbilder: Neuroradiologie', total: 3 },
          { name: 'Krankheitsbilder: Notaufnahme', total: 10 }
        ]
      }
    ]
  },
  {
    id: 'KS3',
    name: 'Interdisziplinäres und interprofessionelles Handeln',
    icon: '👥',
    color: '#534AB7',
    colorBg: '#EEEDFE',
    total: 102,
    bereiche: [
      { id: 'KS3a', name: 'Abstimmungs- und Koordinierungsprozesse im Team', total: 4, themen: [{ name: 'Abstimmungs- und Koordinierungsprozesse', total: 4 }] },
      { id: 'KS3b', name: 'Interprofessionelle und institutionelle Schnittstellen', total: 4, themen: [{ name: 'Interprofessionelle Schnittstellen', total: 4 }] },
      { id: 'KS3c', name: 'Gestaltung patientenorientierter Arbeitsprozesse', total: 11, themen: [{ name: 'Patientenorientierte Arbeitsprozesse', total: 11 }] },
      { id: 'KS3d', name: 'Teamentwicklung', total: 14, themen: [{ name: 'Teamentwicklung', total: 14 }] },
      { id: 'KS3e', name: 'Konfliktmanagement', total: 7, themen: [{ name: 'Konfliktmanagement', total: 7 }] },
      { id: 'KS3f', name: 'Interprofessionelle Kommunikation', total: 46, themen: [{ name: 'Interprofessionelle Kommunikation', total: 46 }] },
      { id: 'KS3g', name: 'Praktische Anleitung', total: 11, themen: [{ name: 'Praktische Anleitung', total: 11 }] },
      { id: 'KS3h', name: 'Organisationsstrukturen operativer Fachgebiete', total: 5, themen: [{ name: 'Organisationsstrukturen', total: 5 }] }
    ]
  },
  {
    id: 'KS4',
    name: 'Bewältigung von beruflichen Anforderungen',
    icon: '📈',
    color: '#0F6E56',
    colorBg: '#E1F5EE',
    total: 77,
    bereiche: [
      { id: 'KS4a', name: 'Berufliches Selbstverständnis', total: 22, themen: [{ name: 'Berufliches Selbstverständnis', total: 22 }] },
      { id: 'KS4b', name: 'Gesundheitspolitik und -ökonomie', total: 11, themen: [{ name: 'Gesundheitspolitik und -ökonomie', total: 11 }] },
      { id: 'KS4c', name: 'Lebenslanges Lernen', total: 10, themen: [{ name: 'Lebenslanges Lernen', total: 10 }] },
      { id: 'KS4d', name: 'Digitales und selbstorganisiertes Lernen', total: 9, themen: [{ name: 'Digitales und selbstorganisiertes Lernen', total: 9 }] },
      { id: 'KS4e', name: 'Wissenschaftliches Arbeiten', total: 11, themen: [{ name: 'Wissenschaftliches Arbeiten', total: 11 }] },
      { id: 'KS4f', name: 'Gesundheitsförderung', total: 14, themen: [{ name: 'Gesundheitsförderung', total: 14 }] }
    ]
  },
  {
    id: 'KS5',
    name: 'Rechtliche Vorgaben und Qualitätskriterien',
    icon: '⚖️',
    color: '#854F0B',
    colorBg: '#FAEEDA',
    total: 130,
    bereiche: [
      { id: 'KS5a', name: 'Rechtliche Vorgaben', total: 59, themen: [{ name: 'Rechtliche Vorgaben', total: 59 }] },
      { id: 'KS5b', name: 'Deutsches Gesundheitswesen', total: 13, themen: [{ name: 'Deutsches Gesundheitswesen', total: 13 }] },
      { id: 'KS5c', name: 'Ökonomische und ökologische Prinzipien', total: 17, themen: [{ name: 'Ökonomische und ökologische Prinzipien', total: 17 }] },
      { id: 'KS5d', name: 'Qualitätsmanagement', total: 13, themen: [{ name: 'Qualitätsmanagement', total: 13 }] },
      { id: 'KS5e', name: 'Fehlermanagement', total: 13, themen: [{ name: 'Fehlermanagement', total: 13 }] },
      { id: 'KS5f', name: 'Dokumentation', total: 11, themen: [{ name: 'Dokumentation', total: 11 }] },
      { id: 'KS5g', name: 'Datenschutz und Datensicherheit', total: 4, themen: [{ name: 'Datenschutz und Datensicherheit', total: 4 }] }
    ]
  },
  {
    id: 'KS6',
    name: 'Kommunikation mit Patienten und Bezugspersonen',
    icon: '💬',
    color: '#085041',
    colorBg: '#E1F5EE',
    total: 81,
    bereiche: [
      { id: 'KS6a', name: 'Psychologie und Soziologie', total: 31, themen: [{ name: 'Psychologie und Soziologie', total: 31 }] },
      { id: 'KS6b', name: 'Empathie und Wertschätzung', total: 11, themen: [{ name: 'Empathie und Wertschätzung', total: 11 }] },
      { id: 'KS6c', name: 'Wahrnehmung und Beobachtung', total: 15, themen: [{ name: 'Wahrnehmung und Beobachtung', total: 15 }] },
      { id: 'KS6d', name: 'Sterbeprozess', total: 15, themen: [{ name: 'Sterbeprozess', total: 15 }] },
      { id: 'KS6e', name: 'Nonverbale Kommunikation', total: 6, themen: [{ name: 'Nonverbale Kommunikation', total: 6 }] },
      { id: 'KS6f', name: 'Beratung im beruflichen Kontext', total: 3, themen: [{ name: 'Beratung im beruflichen Kontext', total: 3 }] }
    ]
  },
  {
    id: 'KS7',
    name: 'Krisen- und Katastrophensituationen',
    icon: '🚨',
    color: '#A32D2D',
    colorBg: '#FCEBEB',
    total: 134,
    bereiche: [
      { id: 'KS7a', name: 'Lebenserhaltende Sofortmaßnahmen', total: 75, themen: [{ name: 'Lebenserhaltende Sofortmaßnahmen', total: 75 }] },
      { id: 'KS7b', name: 'Notfallversorgung', total: 29, themen: [{ name: 'Notfallversorgung', total: 29 }] },
      { id: 'KS7c', name: 'Handeln in Notsituationen', total: 15, themen: [{ name: 'Handeln in Notsituationen', total: 15 }] },
      { id: 'KS7d', name: 'Notfall- und Katastrophenmanagement', total: 15, themen: [{ name: 'Notfall- und Katastrophenmanagement', total: 15 }] }
    ]
  },
  {
    id: 'KS8',
    name: 'Hygienische Arbeitsweisen',
    icon: '🧼',
    color: '#0F6E56',
    colorBg: '#E1F5EE',
    total: 116,
    bereiche: [
      { id: 'KS8a', name: 'Allgemeine und Krankenhaushygiene', total: 11, themen: [{ name: 'Allgemeine und Krankenhaushygiene', total: 11 }] },
      { id: 'KS8b', name: 'Hygienerichtlinien', total: 16, themen: [{ name: 'Hygienerichtlinien', total: 16 }] },
      { id: 'KS8c', name: 'Hygienische Arbeitsweisen', total: 47, themen: [{ name: 'Hygienische Arbeitsweisen', total: 47 }] },
      { id: 'KS8d', name: 'Sterilgutaufbereitung und -versorgung', total: 17, themen: [{ name: 'Sterilgutaufbereitung und -versorgung', total: 17 }] },
      { id: 'KS8e', name: 'Schnittstellenmanagement Sterilgutversorgung', total: 3, themen: [{ name: 'Schnittstellenmanagement Sterilgutversorgung', total: 3 }] },
      { id: 'KS8f', name: 'Arbeits- und Infektionsschutz', total: 22, themen: [{ name: 'Arbeits- und Infektionsschutz', total: 22 }] }
    ]
  }
];

// Compute totals
CURRICULUM.forEach(ks => {
  ks.total = ks.bereiche.reduce((s, b) => s + b.total, 0);
});

if (typeof module !== 'undefined') module.exports = { CURRICULUM };
