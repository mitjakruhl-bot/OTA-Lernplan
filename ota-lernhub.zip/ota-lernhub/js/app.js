// app.js – Haupt-Controller

let currentKS = null;
let currentBereich = null;

// ─── Init ───────────────────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  registerSW();
  renderHome();
  setupNav();
  showScreen('home');
});

function registerSW() {
  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('/sw.js').catch(console.warn);
  }
}

// ─── Navigation ─────────────────────────────────────────────────────────────
function setupNav() {
  document.querySelectorAll('.nav-item').forEach(el => {
    el.addEventListener('click', () => {
      const target = el.dataset.screen;
      if (target === 'quiz') { currentKS = null; startQuiz(null); }
      switchNav(target);
    });
  });
}

function switchNav(name) {
  document.querySelectorAll('.nav-item').forEach(el => el.classList.toggle('active', el.dataset.screen === name));
  if (name !== 'quiz') showScreen(name);
}

function showScreen(name) {
  document.querySelectorAll('.screen').forEach(s => s.classList.remove('active'));
  const el = document.getElementById('sc-' + name);
  if (el) el.classList.add('active');
}

// ─── Home ────────────────────────────────────────────────────────────────────
function renderHome() {
  const { done, total } = getTotalProgress();
  const pct = total > 0 ? Math.round(done / total * 100) : 0;

  document.getElementById('total-pct').textContent = pct + '%';
  document.getElementById('total-bar').style.width = pct + '%';
  document.getElementById('stat-done').textContent = done;
  document.getElementById('stat-total').textContent = total;

  const list = document.getElementById('ks-list');
  list.innerHTML = '';
  CURRICULUM.forEach(ks => {
    const ksp = getKSProgress(ks.id);
    const p = ksp.total > 0 ? Math.round(ksp.done / ksp.total * 100) : 0;
    const col = p >= 80 ? '#1D9E75' : p >= 30 ? '#BA7517' : 'var(--color-muted)';
    list.innerHTML += `
      <div class="ks-card" onclick="openKS('${ks.id}')">
        <div class="ks-row">
          <div class="ks-icon" style="background:${ks.colorBg};color:${ks.color}">${ks.icon}</div>
          <div class="ks-info">
            <div class="ks-name">${ks.id}: ${ks.name}</div>
            <div class="ks-meta">${ksp.done} / ${ksp.total} Einheiten</div>
          </div>
          <div class="ks-right">
            <span class="ks-pct" style="color:${col}">${p}%</span>
            <div class="mini-bar"><div class="mini-fill" style="width:${p}%;background:${col}"></div></div>
          </div>
        </div>
      </div>`;
  });
}

// ─── KS Detail ───────────────────────────────────────────────────────────────
function openKS(ksId) {
  currentKS = CURRICULUM.find(k => k.id === ksId);
  if (!currentKS) return;

  const ksp = getKSProgress(ksId);
  const p = ksp.total > 0 ? Math.round(ksp.done / ksp.total * 100) : 0;

  document.getElementById('d-ks-title').textContent = currentKS.id + ' – ' + currentKS.name;
  document.getElementById('d-ks-bar').style.width = p + '%';
  document.getElementById('d-ks-done').textContent = ksp.done + ' abgeschlossen';
  document.getElementById('d-ks-total').textContent = ksp.total + ' gesamt (' + p + '%)';
  document.getElementById('d-ks-quiz-btn').onclick = () => { startQuiz(ksId); showScreen('quiz'); switchNav('quiz'); };

  const list = document.getElementById('bereich-list');
  list.innerHTML = '';
  currentKS.bereiche.forEach(b => {
    const bp = getBereichProgress(b.id);
    const bp_pct = b.total > 0 ? Math.round(bp.done / b.total * 100) : 0;
    const col = bp_pct >= 80 ? '#1D9E75' : bp_pct >= 30 ? '#BA7517' : 'var(--color-muted)';
    list.innerHTML += `
      <div class="bereich-card" onclick="openBereich('${b.id}')">
        <div class="bereich-info">
          <div class="bereich-name">${b.name}</div>
          <div class="bereich-count">${bp.done} / ${b.total} Einheiten</div>
        </div>
        <span class="bereich-pct" style="color:${col}">${bp_pct}%</span>
        <i class="arrow">›</i>
      </div>`;
  });

  showScreen('ks-detail');
}

// ─── Bereich Detail ──────────────────────────────────────────────────────────
function openBereich(bereichId) {
  const ks = CURRICULUM.find(k => k.bereiche.some(b => b.id === bereichId));
  const bereich = ks?.bereiche.find(b => b.id === bereichId);
  if (!bereich) return;
  currentBereich = bereich;

  const bp = getBereichProgress(bereichId);
  const p = bereich.total > 0 ? Math.round(bp.done / bereich.total * 100) : 0;

  document.getElementById('d-b-title').textContent = bereich.name;
  document.getElementById('d-b-bar').style.width = p + '%';
  document.getElementById('d-b-done').textContent = bp.done + ' / ' + bereich.total + ' (' + p + '%)';

  const list = document.getElementById('thema-list');
  list.innerHTML = '';
  bereich.themen.forEach(t => {
    const checked = bp.themen && bp.themen[t.name];
    list.innerHTML += `
      <div class="thema-row">
        <label class="thema-check">
          <input type="checkbox" ${checked ? 'checked' : ''} onchange="toggleThema('${bereichId}', '${t.name.replace(/'/g, "\\'")}', this.checked)">
          <span class="thema-name">${t.name}</span>
        </label>
        <span class="thema-count">${t.total} LE</span>
      </div>`;
  });

  showScreen('bereich-detail');
}

function toggleThema(bereichId, themaName, done) {
  setThemaDone(bereichId, themaName, done);
  // Refresh bereich detail
  openBereich(bereichId);
  // Refresh home in background
  renderHome();
}

// ─── Export ──────────────────────────────────────────────────────────────────
function exportAnkiFile() {
  const text = exportAnki();
  if (!text.trim()) {
    alert('Noch keine Lernkarten gespeichert. Lade zuerst ein Skript hoch.');
    return;
  }
  const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url; a.download = 'OTA_Lernkarten_Anki.txt';
  a.click();
  URL.revokeObjectURL(url);
}

function resetProgress() {
  if (confirm('Wirklich den gesamten Lernstand zurücksetzen?')) {
    resetAll();
    renderHome();
  }
}
