// storage.js – persistenter Lernstand via localStorage

const STORAGE_KEY = 'ota_lernstand_v1';

function loadProgress() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
  } catch { return {}; }
}

function saveProgress(progress) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(progress));
  } catch (e) {
    console.warn('Storage nicht verfügbar:', e);
  }
}

function getBereichProgress(bereichId) {
  const p = loadProgress();
  return p[bereichId] || { done: 0, themen: {} };
}

function setThemaDone(bereichId, themaName, done) {
  const p = loadProgress();
  if (!p[bereichId]) p[bereichId] = { done: 0, themen: {} };
  p[bereichId].themen[themaName] = done;
  // Recount done for Bereich based on themen
  const bereich = CURRICULUM.flatMap(k => k.bereiche).find(b => b.id === bereichId);
  if (bereich) {
    let total = 0;
    bereich.themen.forEach(t => {
      if (p[bereichId].themen[t.name]) total += t.total;
    });
    p[bereichId].done = total;
  }
  saveProgress(p);
}

function getKSProgress(ksId) {
  const p = loadProgress();
  const ks = CURRICULUM.find(k => k.id === ksId);
  if (!ks) return { done: 0, total: 0 };
  let done = 0;
  ks.bereiche.forEach(b => {
    const bp = p[b.id];
    if (bp) done += bp.done;
  });
  return { done, total: ks.total };
}

function getTotalProgress() {
  const p = loadProgress();
  let done = 0, total = 0;
  CURRICULUM.forEach(ks => {
    total += ks.total;
    ks.bereiche.forEach(b => {
      const bp = p[b.id];
      if (bp) done += bp.done;
    });
  });
  return { done, total };
}

function resetAll() {
  localStorage.removeItem(STORAGE_KEY);
}

function exportAnki() {
  // Returns text in Anki import format (tab-separated: front\tback)
  const questions = JSON.parse(localStorage.getItem('ota_quiz_cards') || '[]');
  return questions.map(q => `${q.front}\t${q.back}`).join('\n');
}

function saveQuizCards(cards) {
  const existing = JSON.parse(localStorage.getItem('ota_quiz_cards') || '[]');
  const merged = [...existing, ...cards];
  localStorage.setItem('ota_quiz_cards', JSON.stringify(merged));
}
