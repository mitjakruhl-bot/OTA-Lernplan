// quiz.js – Quiz-Engine mit eingebauten Fragen

const QUIZ_QUESTIONS = {
  KS1: [
    { front: 'Was ist das Ziel des Team-Time-Out vor einer Operation?', back: 'Gemeinsame Bestätigung von Patientenidentität, geplantem Eingriff und OP-Seite durch alle Beteiligten – bevor der erste Schnitt erfolgt. (WHO Surgical Safety Checklist)', opts: ['Materialien prüfen', 'Identität, Eingriff und Seite gemeinsam bestätigen', 'OP-Saal reinigen', 'Anästhesie einleiten'], correct: 1 },
    { front: 'Welche Prophylaxe ist Standard zur VTE-Prävention im perioperativen Setting?', back: 'Niedermolekulares Heparin (z.B. Enoxaparin) + Kompressionsstrümpfe. Ggf. ergänzt durch Frühmobilisation.', opts: ['Frühmobilisation allein', 'NMH + Kompressionsstrümpfe', 'ASS 100mg', 'Keine Prophylaxe nötig'], correct: 1 },
    { front: 'Was versteht man unter aktivem Wärmemanagement im OP?', back: 'Maßnahmen zur Verhinderung intraoperativer Hypothermie: Warmluftdecken (z.B. Bair Hugger), angewärmte Infusionen, Raumtemperatur ≥21°C, Vorwärmen des Patienten.', opts: ['Raumtemperatur konstant halten', 'Aktive Maßnahmen gegen intraoperative Hypothermie', 'Sterilisationstemperatur überwachen', 'Körpertemperatur unter 35°C halten'], correct: 1 },
    { front: 'Was sind die drei Phasen der präoperativen Pflegevisite?', back: '1. Informationssammlung (Anamnese, Vorerkrankungen, Allergien), 2. Aufklärung/Information des Patienten, 3. Dokumentation und Übergabe ans OP-Team.', opts: ['Aufnahme, OP, Entlassung', 'Informationssammlung, Aufklärung, Dokumentation', 'Labor, EKG, Röntgen', 'Visite, Narkose, Aufwachraum'], correct: 1 },
    { front: 'Welche Lagerungsschäden können im OP auftreten?', back: 'Druckschäden (Dekubitus), Nervenschäden (Lagerungsschäden N. ulnaris, N. radialis), Kompartmentsyndrom, Durchblutungsstörungen, Gelenkschäden.', opts: ['Nur Druckgeschwüre', 'Druck-, Nerven-, Gefäßschäden und Kompartmentsyndrom', 'Ausschließlich Nervenschäden', 'Keine, da kurze OP-Zeiten'], correct: 1 }
  ],
  KS2: [
    { front: 'Was bedeutet Delegation im klinischen Kontext?', back: 'Übertragung ärztlicher Tätigkeiten auf nicht-ärztliches Personal. Der Arzt behält die Anordnungsverantwortung, die OTA trägt Durchführungsverantwortung.', opts: ['Eigenständiges Handeln der OTA', 'Ärztliche Aufgabenübertragung mit geteilter Verantwortung', 'Eigenverantwortliche Diagnosestellung', 'Kollegiale Beratung'], correct: 1 },
    { front: 'Was regelt das MDR (Medical Device Regulation)?', back: 'Sicherheitsanforderungen, Zulassung, Kennzeichnung und Aufbereitung von Medizinprodukten in der EU. Gilt seit 2021, löste MPG/MDD ab.', opts: ['Urlaubsansprüche im Krankenhaus', 'Anforderungen an Medizinprodukte und deren Aufbereitung', 'Personalschlüssel im OP', 'Ärztliche Dokumentationspflichten'], correct: 1 },
    { front: 'Welcher Krankheitslehre-Bereich hat im KS2 die meisten Lerneinheiten?', back: 'Infektionskrankheiten mit 130 Einheiten – spiegelt die Bedeutung von Hygiene und Infektionsprävention im OP wider.', opts: ['Kardiologie', 'Infektionskrankheiten (130 Einheiten)', 'Neurologie', 'Dermatologie'], correct: 1 },
    { front: 'Was ist der Unterschied zwischen Lokalanästhesie und Regionalanästhesie?', back: 'Lokalanästhesie: Betäubung eines umschriebenen Gewebebereichs durch direkte Infiltration. Regionalanästhesie: Ausschaltung größerer Nervenbahnen oder -plexus (z.B. Spinalanästhesie, Plexusblockade).', opts: ['Kein Unterschied', 'Lokal = umschriebenes Gebiet, Regional = größere Nervenbahnen/-plexus', 'Nur Dosierungsunterschied', 'Regional = immer rückenmarksnah'], correct: 1 },
    { front: 'Welche Grundregeln gelten für Injektionen nach ärztlicher Anordnung?', back: '6-R-Regel: richtiger Patient, richtiges Medikament, richtige Dosis, richtiger Zeitpunkt, richtiger Applikationsweg, richtige Dokumentation.', opts: ['3-R-Regel', '6-R-Regel: Patient, Medikament, Dosis, Zeit, Weg, Dokumentation', '5-K-Regel', 'Nur Dosischeck'], correct: 1 }
  ],
  KS3: [
    { front: 'Was ist das Ziel interprofessioneller Kommunikation im OP?', back: 'Sichere, koordinierte Patientenversorgung durch klare Absprachen über Berufsgruppen hinweg, auf Augenhöhe, mit klar definierten Rollen.', opts: ['Hierarchie wahren', 'Sichere Patientenversorgung durch klare berufsübergreifende Absprachen', 'Dokumentation ersetzen', 'Verantwortung delegieren'], correct: 1 },
    { front: 'Was versteht man unter SBAR in der klinischen Kommunikation?', back: 'Strukturiertes Übergabeschema: Situation (was ist passiert?), Background (Hintergrund), Assessment (Einschätzung), Recommendation (Empfehlung).', opts: ['Sicherheits-Bewertungs-Analyse-Report', 'Situation, Background, Assessment, Recommendation', 'Standard-Befund-Aufnahme-Routine', 'Screening-Bogen für Aufnahme-Risiken'], correct: 1 }
  ],
  KS4: [
    { front: 'Was bedeutet lebenslanges Lernen für OTAs?', back: 'Kontinuierliche Aktualisierung von Wissen und Kompetenzen über die gesamte Berufsbiografie durch Fortbildungen, Literatur, Reflexion und kollegialen Austausch.', opts: ['Pflichtfortbildungen alle 10 Jahre', 'Kontinuierliche Weiterentwicklung über die gesamte Berufsbiografie', 'Nur Ausbildungspflichten', 'Ausschließlich digitale Lernformen'], correct: 1 }
  ],
  KS5: [
    { front: 'Was ist der Unterschied zwischen Anordnungs- und Durchführungsverantwortung?', back: 'Anordnungsverantwortung: Arzt verantwortet die Richtigkeit der Anweisung. Durchführungsverantwortung: OTA verantwortet die korrekte Ausführung.', opts: ['Kein Unterschied', 'Arzt = Anordnung, OTA = Durchführung – beide tragen getrennte Verantwortung', 'OTA trägt keine Verantwortung', 'Nur der Arzt ist verantwortlich'], correct: 1 },
    { front: 'Was regelt das KHSG (Krankenhausstrukturgesetz)?', back: 'Qualitätssicherung, Mindestmengen, Krankenhausplanung und Transparenz in der stationären Versorgung. Relevant für Qualitätsmanagement im OP.', opts: ['Nur Personalfragen', 'Qualitätssicherung, Mindestmengen, Krankenhausplanung', 'Ausschließlich Abrechnung', 'Hygienevorschriften'], correct: 1 }
  ],
  KS6: [
    { front: 'Wie kann die OTA zur Reduktion präoperativer Angst beitragen?', back: 'Durch empathische, verständliche Kommunikation, ruhiges Auftreten, aktives Zuhören, Information über Abläufe und Einbeziehung des Patienten in Entscheidungen.', opts: ['Sedierung anordnen', 'Empathische Kommunikation, Information und aktives Zuhören', 'Ablenkung durch Gespräche über andere Themen', 'Patient alleine lassen'], correct: 1 },
    { front: 'Was versteht man unter nonverbaler Kommunikation im Patientenkontakt?', back: 'Körpersprache, Mimik, Gestik, Blickkontakt, Tonfall, räumliche Nähe und Berührung – oft wichtiger als der Inhalt gesprochener Worte.', opts: ['Nur Schriftsprache', 'Körpersprache, Mimik, Gestik, Tonfall und Berührung', 'Fachsprache ohne Erklärung', 'Lautstärke der Sprache'], correct: 1 }
  ],
  KS7: [
    { front: 'Was sind die Sofortmaßnahmen beim intraoperativen Kreislaufstillstand?', back: 'BLS sofort: Thoraxkompressionen 30:2, AED bereitstellen, Notarzt rufen. Parallel: Ursache suchen (4H/HITS). OTA sichert Materialien und unterstützt das Team.', opts: ['Warten auf Arzt', 'Sofort CPR (30:2), AED, Notruf, Ursachensuche', 'OP abbrechen und transportieren', 'Dokumentation priorisieren'], correct: 1 },
    { front: 'Was bedeutet das ABCDE-Schema in der Notfallversorgung?', back: 'Airway (Atemweg), Breathing (Atmung), Circulation (Kreislauf), Disability (neurologischer Status), Exposure (Entkleiden/Umgebung). Strukturierte Erstbeurteilung.', opts: ['Nur für Trauma', 'Airway, Breathing, Circulation, Disability, Exposure', 'Aufnahme-Befund-Check-Dokumentation-Entlassung', 'Allgemein, Blut, Chirurgie, Dienst, Entlassung'], correct: 1 },
    { front: 'Welche Frequenz gilt für Thoraxkompressionen beim Erwachsenen nach ERC-Leitlinien?', back: '100–120 Kompressionen/min, Drucktiefe 5–6 cm, vollständige Entlastung, Verhältnis 30:2 bei 1–2 Helfern ohne gesicherten Atemweg.', opts: ['60–80/min', '100–120/min, 5–6 cm tief, 30:2', '80–100/min', '120–140/min'], correct: 1 }
  ],
  KS8: [
    { front: 'Was ist der Unterschied zwischen Desinfektion und Sterilisation?', back: 'Desinfektion: Reduktion der Keimzahl auf nicht-infektiöses Maß (Sporen bleiben ggf. erhalten). Sterilisation: vollständige Abtötung ALLER Mikroorganismen inkl. Sporen und Prionen.', opts: ['Kein Unterschied', 'Desinfektion = Keimreduktion, Sterilisation = vollständige Keimfreiheit inkl. Sporen', 'Sterilisation nur für Instrumente', 'Desinfektion tötet alle Sporen'], correct: 1 },
    { front: 'Welche Händedesinfektion ist im OP-Bereich vorgeschrieben?', back: 'Chirurgische Händedesinfektion: 3–5 Minuten, Hände und Unterarme mit alkoholischem Desinfektionsmittel einreiben. Ziel: transiente Flora eliminieren, residente Flora reduzieren.', opts: ['Seife 30 Sekunden', 'Chirurgische HD: 3–5 Min. mit Alkohol, Hände und Unterarme', 'Hygienische HD reicht aus', 'Handschuhe ohne Desinfektion'], correct: 1 },
    { front: 'Was bedeutet RKI-Einstufung in Aufbereitungsklassen?', back: 'Unkritisch (Hautkontakt), semikritisch (Schleimhaut/verletzte Haut → Desinfektion), kritisch (invasiv in sterile Körperbereiche → Sterilisation erforderlich).', opts: ['Nur 2 Klassen', 'Unkritisch, semikritisch, kritisch – je nach Kontaktrisiko', 'Alle Instrumente gleich behandeln', 'Nur für Einmalinstrumente'], correct: 1 }
  ]
};

let quizState = {
  questions: [],
  currentIdx: 0,
  answered: false,
  ksId: null
};

function startQuiz(ksId) {
  const questions = ksId ? (QUIZ_QUESTIONS[ksId] || []) : Object.values(QUIZ_QUESTIONS).flat();
  quizState = { questions: shuffle(questions), currentIdx: 0, answered: false, ksId };
  renderQuizQuestion();
}

function shuffle(arr) {
  return [...arr].sort(() => Math.random() - 0.5);
}

function renderQuizQuestion() {
  const q = quizState.questions[quizState.currentIdx];
  if (!q) return;
  const total = quizState.questions.length;
  const idx = quizState.currentIdx;

  document.getElementById('q-meta').textContent =
    (quizState.ksId || 'Alle KS') + ' · Frage ' + (idx + 1) + ' / ' + total;
  document.getElementById('q-text').textContent = q.front;
  document.getElementById('q-explain').style.display = 'none';
  document.getElementById('q-explain').textContent = '';
  document.getElementById('q-next').style.display = 'none';
  quizState.answered = false;

  const optsEl = document.getElementById('q-opts');
  optsEl.innerHTML = '';
  q.opts.forEach((opt, i) => {
    const btn = document.createElement('button');
    btn.className = 'qopt';
    btn.textContent = opt;
    btn.addEventListener('click', () => answerQuiz(i));
    optsEl.appendChild(btn);
  });
}

function answerQuiz(idx) {
  if (quizState.answered) return;
  quizState.answered = true;
  const q = quizState.questions[quizState.currentIdx];
  document.querySelectorAll('.qopt').forEach((btn, i) => {
    btn.removeEventListener('click', () => {});
    if (i === q.correct) btn.classList.add('correct');
    else if (i === idx) btn.classList.add('wrong');
  });
  const explain = document.getElementById('q-explain');
  explain.textContent = q.back;
  explain.style.display = 'block';
  document.getElementById('q-next').style.display = 'block';
}

function nextQuizQuestion() {
  quizState.currentIdx++;
  if (quizState.currentIdx >= quizState.questions.length) {
    document.getElementById('q-text').textContent = '✅ Quiz abgeschlossen! Alle ' + quizState.questions.length + ' Fragen beantwortet.';
    document.getElementById('q-opts').innerHTML = '';
    document.getElementById('q-explain').style.display = 'none';
    document.getElementById('q-next').style.display = 'none';
    document.getElementById('q-meta').textContent = 'Fertig!';
    return;
  }
  renderQuizQuestion();
}
