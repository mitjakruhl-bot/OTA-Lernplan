# OTA Lernhub 🏥

Lernplattform für die OTA-Ausbildung – ATA/OTA 24, Klinikum Bremerhaven-Reinkenheide.  
Basiert auf dem eRef Thieme Curriculum (KS1–KS8, 3182 Lerneinheiten).

## Features
- ✅ Vollständiges Curriculum KS1–KS8 mit allen Unterebenen
- ✅ Lernfortschritt per Thema abhaken (bleibt dauerhaft gespeichert)
- ✅ Quiz mit echten OTA-Prüfungsfragen
- ✅ Offline-fähig (PWA mit Service Worker)
- ✅ Installierbar auf iOS & Android
- ✅ Dark Mode

## Deployment (einmalig, ~10 Minuten)

### 1. GitHub
1. Gehe zu [github.com](https://github.com) → Account erstellen (kostenlos)
2. „New repository" → Name: `ota-lernhub` → Public → Create
3. Alle Dateien dieses Ordners per Drag & Drop in den Repository-Browser ziehen
4. „Commit changes" klicken

### 2. Vercel
1. Gehe zu [vercel.com](https://vercel.com) → „Sign up with GitHub"
2. „New Project" → dein Repository `ota-lernhub` auswählen → Deploy
3. Fertig – du bekommst eine URL wie `ota-lernhub.vercel.app`

### App auf Handy installieren
- **iOS**: Safari → URL öffnen → Teilen (□↑) → „Zum Homescreen hinzufügen"
- **Android**: Chrome → URL öffnen → Menü (⋮) → „App installieren"

## Dateistruktur
```
ota-lernhub/
├── index.html          # Haupt-App
├── manifest.json       # PWA-Manifest
├── sw.js               # Service Worker (Offline)
├── css/
│   └── style.css       # Stylesheet
├── js/
│   ├── curriculum.js   # Vollständiges Curriculum KS1–KS8
│   ├── storage.js      # Lernstand (localStorage)
│   ├── quiz.js         # Quiz-Engine + Fragen
│   └── app.js          # App-Controller
└── icons/
    ├── icon-192.png    # App-Icon (192×192) – selbst erstellen
    └── icon-512.png    # App-Icon (512×512) – selbst erstellen
```

## Icons erstellen
Öffne [favicon.io](https://favicon.io/favicon-generator/) → Text: „OTA" → Farbe: #0D3D56  
Download → icon-192.png und icon-512.png in `/icons/` ablegen.

## Nächste Schritte (optional)
- Claude-API-Integration für automatische Kartengenerierung aus Skripten
- Spaced-Repetition-Algorithmus (SM-2)
- Lernplan-Export als PDF
